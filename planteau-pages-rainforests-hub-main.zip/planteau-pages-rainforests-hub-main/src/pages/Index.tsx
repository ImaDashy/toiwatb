
import BookPurchase from "@/components/BookPurchase";

const Index = () => {
  return <BookPurchase />;
};

export default Index;
